// Copyright 2022 The Bazel Authors. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package roll

import (
	"math/rand"
	"strconv"
	"time"

	"k8s.io/klog/v2"
)

func Roll() string {
	klog.Info("rolling the dice")
	return generateNumber()
}

func generateNumber() string {
	source := rand.NewSource(time.Now().UnixNano())
	random := rand.New(source)
	return strconv.Itoa(random.Intn(100))
}
